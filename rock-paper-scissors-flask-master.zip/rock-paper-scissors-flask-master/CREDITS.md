# Credits, Notes, and Reference

  + [Gameplay Logic and Images](https://github.com/prof-rossetti/rock-paper-scissors-py)
  + [Example Flask App](https://github.com/prof-rossetti/web-app-starter-flask)
